// Rotas das PÁGINAS (HTML renderizado pelo EJS).
// As rotas de DADOS (JSON) ficam em /api, em outros arquivos de rotas.
import { Router } from 'express';

const router = Router();

router.get('/', (req, res) => {
  res.render('index', { titulo: 'SalesFlow' });
});

export default router;
