import { AppError } from '../utils/AppError.js';

// Roda quando nenhuma rota atendeu ao pedido: vira um erro 404.
export function rotaNaoEncontrada(req, res, next) {
  next(new AppError(404, 'Rota não encontrada.', 'NAO_ENCONTRADO'));
}

// Todo erro do sistema cai aqui. O Express reconhece esta função como
// "tratador de erros" porque ela tem 4 parâmetros (o primeiro é o erro).
// Toda resposta de erro tem o mesmo formato: { erro: { codigo, mensagem } }
export function tratarErros(erro, req, res, next) {
  let status = 500;
  let codigo = 'ERRO_INTERNO';
  let mensagem = 'Erro interno do servidor.';

  if (erro instanceof AppError) {
    status = erro.status;
    codigo = erro.codigo;
    mensagem = erro.message;
  } else if (erro.type === 'entity.parse.failed') {
    // Alguém enviou um JSON mal formado.
    status = 400;
    codigo = 'JSON_INVALIDO';
    mensagem = 'O corpo da requisição não é um JSON válido.';
  }

  // Erros inesperados (500) vão para o log, mas o detalhe NÃO é mostrado ao usuário.
  if (status >= 500) {
    console.error(erro);
  }

  res.status(status).json({ erro: { codigo, mensagem } });
}
